<?php

class Services_Twilio_Rest_Token extends Services_Twilio_InstanceResource {

}
