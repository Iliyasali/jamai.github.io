<?php

class Services_Twilio_Rest_DependentPhoneNumbers
    extends Services_Twilio_ListResource
{
}
