// JavaScript Document
var $ = jQuery.noConflict();
