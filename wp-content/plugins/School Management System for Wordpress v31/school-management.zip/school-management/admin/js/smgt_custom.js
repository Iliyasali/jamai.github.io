// JavaScript Document
$(document).ready(function() {
	if ($("#example").length > 0){
    $('#example').DataTable();
	}
} );